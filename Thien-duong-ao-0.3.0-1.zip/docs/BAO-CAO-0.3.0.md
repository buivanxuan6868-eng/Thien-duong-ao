# Bản 0.3.0 thử nghiệm Đảo Tình Yêu — 28/10/2026

**Đã lập trình và kiểm thử trong môi trường phát triển. Chưa cập nhật GitHub/Pages.** Website của chủ dự án vẫn giữ 0.2.1 đã chạy được. Bản này là tiến độ giai đoạn 1, chưa hoàn tất toàn bộ tiêu chuẩn hình ảnh/nhân vật chân thực của bản bàn giao tổng thể.

## Điểm xuất phát đã kiểm tra

Nhánh main trên GitHub: `723dcd6dc5f4fd2a09809576da83fb31527abe1c`, bản một tệp 0.2.1 do chủ kho tải lên. Đã đọc lại mã nguồn và đối chiếu với bản đã kiểm thử; trong phiên trước Pages đã trả đúng byte của bản này và chủ dự án đã xác nhận chạy được trên Android.

Trong đợt mới, yêu cầu HEAD tới Pages trả HTTP 200, Date và Age hợp lệ. Chrome headless không kết nối trực tiếp được tới địa chỉ công khai trong môi trường này (`ERR_EMPTY_RESPONSE`); kiểm tra dựng hình mới dùng chính tệp nguồn qua tuyến kiểm thử `/Thien-duong-ao/`, với WebGL thật bằng SwiftShader. Không coi đây là kiểm thử bản 0.3 đã triển khai hoặc Android thật.

Đánh giá 0.2.1: đảo/cây/hoa/nhân vật hiển thị được nhưng còn phong cách hình khối đơn giản; thiếu va chạm với cảnh, đồng hồ phụ thuộc giờ máy, nút thời tiết cho phép người chơi đổi cục bộ.

## Đã thực hiện

- Lá dừa cong, hoa có cánh 3D thay các hình nón/khối hoa cũ. Cụm cây nhiều tán, đá mềm hơn, đường ven biển, chòi nghỉ và đảo xa 3D.
- Vật liệu cỏ/cát/gỗ/đá có vân tự tạo, không thêm ảnh CDN. Mặt biển biến dạng nhẹ, thác có vân chảy và sương, mây 3D, mặt trời, sao và chuyển màu hoàng hôn. Vẫn dùng hình học 3D, không thay bằng ảnh phẳng.
- Va chạm cơ bản với thân cây, đá, ghế, đèn, hồ và lan can cầu. Cầu được kéo dài để qua hồ được; nhân vật nâng lên mặt cầu và bị giới hạn trong đảo. Chia nhỏ bước di chuyển để hạn chế xuyên vật cản. Có xử lý trượt dọc vật cản và tránh camera đi vào một số vật thể dựa trên khối va chạm đơn giản.
- Vuốt ngang/dọc để quan sát, giới hạn góc dọc; giữ điều khiển cảm ứng/bàn phím, hai góc nhìn, chuyển động mẫu và bạn mô phỏng. Nhãn giao diện không đếm nhân vật mô phỏng thành người trực tuyến thật.
- Thời gian đồng bộ từ HTTP Date của chính origin, hiệu chỉnh Age/độ trễ rồi neo bằng `performance.now()`. Sau đồng bộ, đổi đồng hồ máy không làm đổi thời gian thế giới. Đồng bộ lại định kỳ 5 phút; nếu chưa lấy được nguồn thời gian, hiển thị rõ chưa đồng bộ. Không có nút tự chỉnh giờ cho người chơi. Đã thử HEAD trên Pages thực tế có header phù hợp.
- Thời tiết Hà Nội cập nhật 15 phút; có timeout, kiểm tra schema, cache lần gần nhất và nhãn dữ liệu cũ khi lỗi. Mưa/mây/sương mù có trạng thái riêng. Nút người chơi chỉ xem thông tin khí hậu và nguồn Open-Meteo; thử đổi thời tiết chỉ xuất hiện khi mở `?debug` và chỉ tác động phiên kiểm thử cục bộ.
- Vẫn giữ Three.js nội bộ, cơ chế báo lỗi, giới hạn pixel, giảm chất lượng theo mẫu đo, chia sẻ geometry và InstancedMesh.

## Tệp chính

`index.html`, `world.js`, `environment.js`, `scripts/build-single-file.py`, `single-file/index.html`, tài liệu trong `docs`, và các kịch bản/kết quả trong `tests`.

Bản một tệp chứa đủ thư viện, module thời gian/thời tiết và mã cảnh, không cần chép thêm thư mục vendor. Đã giữ giấy phép Three.js. Việc lưu thời tiết là cục bộ; chưa có lưu ảnh mặt, tài khoản hoặc dữ liệu riêng tư lên máy chủ.

## Kiểm thử và giới hạn

Đạt 21 nhóm kiểm tra tự động (kể cả bản một tệp và giao diện người chơi không có nút đổi thời tiết). Kiểm thử riêng dịch vụ thời gian/thời tiết cũng đạt. Cảnh mở đầu ghi 55 draw calls và 75.214 tam giác; sau tương tác lặp, geometry giữ 74→74 và chương trình shader 12→12. Một mẫu 5 giây trên SwiftShader là 27,6 FPS; không đại diện tốc độ trên Android, không cam kết 30/60 FPS.

Kết quả chi tiết nằm ở `tests/results-03.json`, nhật ký `tests/verify-03.log` và kiểm thử dịch vụ `tests/environment-03.mjs`. Kiểm thử Chrome for Testing 145.0.7632.6, WebGL 2 phần mềm, màn hình mô phỏng. Cú pháp các module và bootstrap được kiểm tra riêng. Không tuyên bố đã chạy 0.3.0 trên điện thoại Android thật.

Đồ họa vẫn chưa đạt ảnh thực hoặc chất lượng nhân vật cuối cùng. Nhân vật vẫn là mẫu kỹ thuật như nhãn đang ghi; cần mẫu GLB có xương, tóc, vật liệu da và clip đi bộ phù hợp. Đề xuất công nghệ/kế hoạch chi phí nằm trong `NHAN-VAT-VA-LO-TRINH.md`.

Đồng hồ HTTP là bước tiến ở client, chưa phải dịch vụ thời gian chống gian lận. Người cùng mạng tốt sẽ bám cùng nguồn UTC+7, nhưng chưa có backend cấp một snapshot thời tiết cho mọi phiên. Khi mất mạng, trạng thái dự phòng giữa máy có thể khác; chưa được gọi là đã hoàn thiện đồng bộ thế giới nhiều người chơi.

Va chạm là xấp xỉ đường tròn/hộp, chưa phải vật lý địa hình tổng quát; chưa có nhảy/bơi hoặc nhiều tầng. Chưa đo hiệu năng và bộ nhớ dài hạn trên GPU điện thoại. Không cam kết 30/60 FPS Android.

## Quyền ghi và triển khai

Thử tạo nhánh sao lưu trên GitHub một lần trong đợt này tiếp tục nhận `403 — Resource not accessible by integration`. Không đẩy hoặc ghi đè bản đang chạy. Nhánh phát triển cục bộ dựa trực tiếp trên commit 0.2.1 đã triển khai, đồng thời giữ nhánh/bản sao 0.2.1.

Trang hiện tại: https://buivanxuan6868-eng.github.io/Thien-duong-ao/

Bản 0.3.0 trong gói bàn giao là bản thử, chưa phải URL xuất bản mới. Nếu cần cập nhật thủ công, dùng đúng `index.html` ngoài cùng của gói; mở thử tệp trước được, và chỉ cần tải một tệp lên kho khi chủ dự án muốn dùng bản thử. Không cần chỉnh Pages hoặc xóa bản cũ; lịch sử Git vẫn giữ commit trước.
