# Nhân vật và lộ trình kỹ thuật — 28/10/2026

Đây là đánh giá kỹ thuật và đề xuất để thực hiện bản bàn giao. Chưa triển khai xử lý ảnh mặt thật, chưa tạo tài khoản dịch vụ hoặc mua gói trả phí.

## Đánh giá hiện tại

Nhân vật trong 0.3.0 vẫn là mẫu hình học để kiểm tra camera, tỷ lệ và điều khiển. Chưa đạt yêu cầu người thật, tóc thật, biểu cảm hoặc chuyển động tự nhiên cuối cùng. Không được dùng mẫu này để tuyên bố đã hoàn thiện avatar.

Giữ Three.js r170 trong đợt này. Bộ tải GLTFLoader và hệ thống AnimationMixer của Three.js hỗ trợ mô hình có xương và clip chuyển động. Đổi sang Unity không tự giải quyết chất lượng khuôn mặt hoặc chi phí sản xuất tài nguyên.

- Tài liệu gốc: https://threejs.org/docs/pages/GLTFLoader
- Animation: https://threejs.org/manual/pages/animation-system.html

## Đường đi ít tốn kém trước

Bước tiếp theo nên là hai mẫu nam/nữ có quyền sử dụng rõ ràng, xuất GLB từ Blender/MakeHuman, sau đó thử đứng và đi bộ trong chính cảnh đảo. Mẫu tóc/quần áo phải được kiểm tra giấy phép riêng nếu lấy ngoài bộ mặc định. MakeHuman cho phép khai thác bản xuất CC0; điều này không có nghĩa mọi tài nguyên cộng đồng đều cùng giấy phép.

Nguồn gốc:
https://static.makehumancommunity.org/makehuman/faq/can_i_sell_models_created_with_makehuman.html
https://static.makehumancommunity.org/makehuman/releases/releases_120.html

Ngân sách kỹ thuật đề xuất, chưa phải số đã đạt: 15–30 nghìn tam giác/người ở bản gần; 3–8 nghìn ở xa; texture 1K trước, có thể KTX2 sau khi đo; mục tiêu tệp tải xuống 1–3 MB/người. Giới hạn người nhìn thấy, mức chi tiết và số shader phải được đo trên Android thật. Không gắn nhãn người thật nếu chưa có tài khoản và kết nối máy chủ.

## Tạo khuôn mặt từ ảnh

Phương án có khả năng tích hợp: một dịch vụ chuyên tạo avatar toàn thân có xương như MetaPerson. API chính thức hỗ trợ ảnh → đầu/người, tóc, trang phục, blendshape và GLB. Tính giống người, mức làm đẹp và chuyển động phải được đánh giá thực nghiệm bằng ảnh có sự đồng ý; tài liệu quảng cáo không đủ chứng minh đạt yêu cầu của dự án.

Nguồn:
https://docs.metaperson.avatarsdk.com/rest_api/
https://avatarsdk.com/metaperson-creator/
https://avatarsdk.com/pricing-cloud/

Giá công khai tại thời điểm đọc trang: mục Pro hiển thị 800 USD/tháng, 1.000 avatar/tháng, phát sinh 0,03 USD/avatar; có điều kiện quy mô doanh nghiệp và lựa chọn kỳ thanh toán trên trang. Cần xác nhận lại giá theo kỳ trước khi mua. Mức hiển thị này không phù hợp để tự động đăng ký cho một thử nghiệm tiết kiệm. Trang cũng nêu có thể tạo/xuất lẻ và avatar đầu miễn phí; chưa thử nghiệm hoặc xác nhận quyền thương mại cụ thể của một mẫu đã xuất. Đề xuất thử tối đa một mẫu có sự đồng ý trước, chưa bật API công khai.

Phương án tự chạy AI không đồng nghĩa miễn phí: còn GPU, bảo trì và giấy phép. Ví dụ DECA/FLAME có giới hạn dùng cho nghiên cứu phi thương mại theo giấy phép đang công bố; không chọn làm nền cho sản phẩm vận hành thương mại khi chưa giải quyết quyền sử dụng.

https://github.com/yfeng95/DECA/blob/master/LICENSE
https://flame.is.tue.mpg.de/modellicense.html

Meshy có API ảnh sang 3D, nhưng từ chức năng đó không thể suy ra chất lượng giữ danh tính, topology mặt, rig hoặc độ ổn định biểu cảm đạt yêu cầu. Chưa chọn Meshy làm công nghệ khuôn mặt. Tài liệu giá dùng đơn vị credits, không thể coi một credit là một USD hoặc tự suy ra chi phí tiền mặt.

https://docs.meshy.ai/en/api/multi-image-to-3d
https://docs.meshy.ai/en/api/pricing

## Luồng dữ liệu đề xuất

1. Người dùng được giải thích rõ mục đích, nơi xử lý và thời hạn lưu; đồng ý trước khi ảnh được gửi.
2. Trình duyệt bỏ metadata ảnh và giảm kích thước hợp lý. Không cần GPS của người dùng; môi trường luôn là Hà Nội.
3. Ảnh gốc nằm trong kho riêng, quyền truy cập theo tài khoản; URL ký ngắn hạn. Không lưu ảnh vào GitHub công khai. Khóa API chỉ nằm trên máy chủ.
4. Máy chủ gửi ảnh tới nhà cung cấp đã chọn, nhận mô hình, kiểm tra định dạng/dung lượng/tài nguyên tham chiếu rồi lưu bản avatar. Không nhận tùy ý URL lạ để trình duyệt tải tài nguyên không kiểm soát.
5. Người dùng xem trước và duyệt khuôn mặt. Chỉnh ánh sáng/texture nhẹ trước; không đổi mạnh hình học nhận diện. So sánh trước/sau bằng người duyệt, chưa đặt ngưỡng tự động chưa được kiểm chứng.
6. Thời gian `face_changed_at` do máy chủ ghi trong giao dịch nguyên tử. Chỉ cho thay hình dạng mặt khi thời gian máy chủ đã qua đủ 90 ngày; thay tóc/quần áo không cập nhật mốc này.
7. Xóa ảnh/tài khoản được phép độc lập với giới hạn 90 ngày; thu hồi URL và xóa dữ liệu nhà cung cấp theo cơ chế của họ. Mốc 90 ngày không được dùng để ngăn quyền xóa hoặc xử lý sự cố bảo mật.

Chưa có backend nên chưa thể triển khai quy tắc 90 ngày một cách đáng tin cậy chỉ bằng localStorage. Cũng chưa triển khai nhận diện danh tính pháp lý hoặc cam kết chống sử dụng ảnh của người khác.

## Trước giai đoạn nhiều người chơi

Cần máy chủ cấp trạng thái thế giới chung, tài khoản, quyền truy cập và đồng bộ vị trí. GitHub Pages chỉ phục vụ tệp tĩnh; đồng hồ HTTP ở 0.3.0 không thay thế máy chủ xác thực, và đọc cùng API thời tiết chưa bảo đảm mọi người nhận đúng một snapshot khi mất mạng/cache khác nhau.

Trước giao tiếp công khai phải có chặn, báo cáo, hạn chế tần suất và xử lý quấy rối. Chưa bật giọng nói, nắm tay, hẹn hò, thanh toán hoặc theo dõi người dùng. Chi phí các phần này phải được chốt sau một thử nghiệm nhỏ.

## Phân biệt chi phí

- Đợt 0.3.0: không mua tài nguyên, không đăng ký dịch vụ, không gọi API AI trả phí. Tài nguyên cảnh hiện có/tự tạo; không thêm chi phí máy chủ vận hành mới.
- Tạo hai mẫu GLB thủ công: có thể không tốn phí bản quyền công cụ với Blender/MakeHuman; vẫn có công sức sản xuất, tối ưu và kiểm thử, chưa báo giá thuê ngoài.
- Ảnh → avatar thương mại: phí nhà cung cấp + xử lý + lưu trữ/băng thông; chưa tích hợp hoặc phát sinh phí.
- Multiplayer/voice: cần máy chủ/băng thông và đo quy mô trước khi ước tính tiền; không thể hứa miễn phí ở mọi quy mô.
- Open-Meteo hiện dùng cho thử nghiệm cá nhân không thương mại; cần xem lại gói phù hợp trước vận hành thương mại. Nguồn và giới hạn: https://open-meteo.com/en/terms .
