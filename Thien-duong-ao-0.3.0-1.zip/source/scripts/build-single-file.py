"""Tạo bản index.html chứa trọn Three.js và mã cảnh, không cần CDN."""
from pathlib import Path
import base64
root = Path(__file__).resolve().parents[1]
html = (root / 'index.html').read_text()
for name in ('vendor/three-r170/three.module.js', 'world.js'):
    url = './' + name + ('?v=0.3.0' if name == 'world.js' else '')
    data_bytes = (root / name).read_bytes()
    if name == 'world.js':
        env = base64.b64encode((root / 'environment.js').read_bytes()).decode()
        data_bytes = data_bytes.replace(b"./environment.js", ('data:text/javascript;base64,' + env).encode())
    data = base64.b64encode(data_bytes).decode()
    html = html.replace(url, 'data:text/javascript;base64,' + data)
license_text = (root / 'vendor/three-r170/LICENSE').read_text()
html = html.replace('<!doctype html>', '<!doctype html>\n<!-- Three.js r170 — MIT License\n' + license_text + '\n-->')
(root / 'single-file').mkdir(exist_ok=True)
(root / 'single-file/index.html').write_text(html)
