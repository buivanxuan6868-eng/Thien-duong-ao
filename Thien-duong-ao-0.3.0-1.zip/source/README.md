# Thien-duong-ao
Thế giới du lịch thiên đường ảo 3D.

## Trạng thái

Bản công khai đã được chủ dự án cập nhật là 0.2.1. Nhánh phát triển này là bản thử 0.3.0, chưa đẩy GitHub Pages do kết nối thiếu quyền ghi (403).

## Chạy và đóng gói

Phục vụ thư mục gốc qua HTTP(S) để chạy bản module. Dùng `python3 scripts/build-single-file.py` để tạo `single-file/index.html`, chứa đủ Three.js và hai module của dự án. Tệp một trang này có thể thay đúng một tệp index.html trên GitHub Pages.

Thông tin tiến độ và giới hạn: `docs/BAO-CAO-0.3.0.md`. Đánh giá nhân vật/ảnh thật/chi phí: `docs/NHAN-VAT-VA-LO-TRINH.md`.

Nhân vật hiện vẫn là mẫu kỹ thuật. Chưa có multiplayer, AI xử lý ảnh hoặc hệ thống tài khoản. Chế độ kiểm thử chỉ hiện khi thêm `?debug`; không thay đổi trạng thái người chơi khác.
