# Tái lập kiểm thử 0.3.0

Chạy từ thư mục mã nguồn. Cần Node.js và Playwright (npm install --no-save playwright; npx playwright install chromium).

- node tests/environment-03.mjs
- node tests/verify-03.cjs

Có thể chỉ định CHROME_PATH tới Chrome/Chromium và THIEN_SOURCE_DIR tới thư mục mã. Khi chạy, kịch bản dùng định tuyến tệp nội bộ và dữ liệu thời tiết có kiểm soát; không gọi dịch vụ AI. Sử dụng SwiftShader cho WebGL phần mềm. Kết quả này không thay cho kiểm thử Android thật. Cần tạo thư mục tests trước khi chạy (đã có sẵn trong gói).
